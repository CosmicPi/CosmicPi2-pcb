Here are some documents for the verification of the mechanical drawings. Your help is requested in checking the mechanical fit of our board with the holes we're getting machined in the box. Please take a look and share with us your comments about the mechanical design.

The board will be fixed to the chassis with 4 metal M3 thread screws with plastic washers. The front plate will be held in place by the structrure of the chassis.
